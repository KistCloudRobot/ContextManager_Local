package kgu.agent.demo.actionArgument;
import org.json.simple.JSONObject;

import kr.ac.uos.ai.arbi.agent.ArbiAgent;
import kr.ac.uos.ai.arbi.agent.ArbiAgentExecutor;
import kr.ac.uos.ai.arbi.ltm.DataSource;


public class ContextOntologyMonitorArgument {
		
	private String COMgraph;
	private String COMtriples;
	private String COMclasses;
	private String COMindividuals;
	private String COMobjectproperties;
	private String COMdatatypeproperties;


	
	
	
	public String getCOMgraph() {
		return COMgraph;
	}public void setCOMgraph(String COMgraph) {
		this.COMgraph = COMgraph;
	}
	
	
	public String getCOMtriples() {
		return COMtriples;
	}public void setCOMtriples(String COMtriples) {
		this.COMtriples = COMtriples;
	}
	
	
	public String getCOMclasses() {
		return COMclasses;
	}public void setCOMclasses(String COMclasses) {
		this.COMclasses = COMclasses;
	}
	
	
	public String getCOMindividuals() {
		return COMindividuals;
	}public void setCOMindividuals(String COMindividuals) {
		this.COMindividuals = COMindividuals;
	}
	
	
	public String getCOMobjectproperties() {
		return COMobjectproperties;
	}public void setCOMobjectproperties(String COMobjectproperties) {
		this.COMobjectproperties = COMobjectproperties;
	}
	
	
	public String getCOMdatatypeproperties() {
		return COMdatatypeproperties;
	}public void setCOMdatatypeproperties(String COMdatatypeproperties) {
		this.COMdatatypeproperties = COMdatatypeproperties;
	}
	
	
	//액션에 사용되는 인자는 toString 함수를 통해 원하는 로그로 변환됨
		//로그 기능을 사용하기 위해서는 반드시 Override 해야 함
		//일반적으로 JSON 형식으로 전달
		public String toString() {
			JSONObject obj = new JSONObject();

			obj.put("COMgraph",COMgraph);
			obj.put("COMtriples",COMtriples);
			obj.put("COMclasses",COMclasses);
			obj.put("COMindividuals",COMindividuals);
			obj.put("COMibjectproperties",COMobjectproperties);
			obj.put("COMdatatypeproperties",COMdatatypeproperties);
			return obj.toJSONString();
		}

}
