package kgu.agent.demo.actionArgument;
import org.json.simple.JSONObject;

import kr.ac.uos.ai.arbi.agent.ArbiAgent;
import kr.ac.uos.ai.arbi.agent.ArbiAgentExecutor;
import kr.ac.uos.ai.arbi.ltm.DataSource;


public class LowLevelContextMonitorArgument {
		
	private String LCMgraph;
	private String LCMtriples;
	private String LCMobjectPerception;
	private String LCMhumanPerception;
	private String LCMrobotPerception;


	public String getLCMgraph() {
		return LCMgraph;
	}public void setLCMgraph(String LCMgraph) {
		this.LCMgraph = LCMgraph;
	}
	
	public String getLCMtriples() {
		return LCMtriples;
	}public void setLCMtriples(String LCMtriples) {
		this.LCMtriples = LCMtriples;
	}
	
	public String getLCMobjectPerception() {
		return LCMobjectPerception;
	}public void setLCMobjectPerception(String LCMobjectPerception) {
		this.LCMobjectPerception = LCMobjectPerception;
	}
	
	public String getLCMhumanPerception() {
		return LCMhumanPerception;
	}public void setLCMhumanPerception(String LCMhumanPerception) {
		this.LCMhumanPerception = LCMhumanPerception;
	}
	
	public String getLCMrobotPerception() {
		return LCMrobotPerception;
	}public void setLCMrobotPerception(String LCMrobotPerception) {
		this.LCMrobotPerception = LCMrobotPerception;
	}
	
	
	
	

	
	//액션에 사용되는 인자는 toString 함수를 통해 원하는 로그로 변환됨
		//로그 기능을 사용하기 위해서는 반드시 Override 해야 함
		//일반적으로 JSON 형식으로 전달
		public String toString() {
			JSONObject obj = new JSONObject();
			obj.put("LCMgraph",LCMgraph);
			obj.put("LCMtriples",LCMtriples);
			obj.put("LCMobjectPerception",LCMobjectPerception);
			obj.put("LCMhumanPerception",LCMhumanPerception);
			obj.put("LCMrobotPerception",LCMrobotPerception);

			return obj.toJSONString();
		}

}
