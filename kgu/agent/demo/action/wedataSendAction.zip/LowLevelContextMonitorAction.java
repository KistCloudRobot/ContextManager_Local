package kgu.agent.demo.action;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.Integer;
import java.util.Hashtable;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;

import jpl.*;
import org.json.simple.parser.JSONParser;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.formats.OWLXMLDocumentFormat;
import org.semanticweb.owlapi.formats.RDFJsonDocumentFormat;
import org.semanticweb.owlapi.model.OWLDocumentFormat;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.OWLOntologyStorageException;

import kgu.agent.demo.actionArgument.LowLevelContextMonitorArgument;
import kgu.agent.demo.actionArgument.WebDataArgument;
//import kgu.agent.demo.actionArgument.GLArgument;
import kgu.agent.demo.actionArgument.WorkingMemory_MonitorsArgument;
import kr.ac.uos.ai.arbi.agent.logger.ActionBody;
import kr.ac.uos.ai.arbi.ltm.DataSource;
import kr.ac.uos.ai.arbi.model.GLFactory;
import kr.ac.uos.ai.arbi.model.GeneralizedList;
import kr.ac.uos.ai.arbi.model.parser.ParseException;
import kgu.agent.demo.agent.ContextManager;

import kgu.agent.demo.action.webdataformat.SharedData;

public class LowLevelContextMonitorAction implements ActionBody{

	
	public static final String JMS_BROKER_URL = "tcp://127.0.0.1:61616";
	public static final String TM_ADDRESS = "agent://www.arbi.com/taskManager";
	public static final String KM_ADDRESS = "agent://www.arbi.com/knowledgeManager";
	public static final String DC_URL = "dc://testWebDataSendCM";
	private DataSource ds;

	SharedData SD = new SharedData();
	
	
	public LowLevelContextMonitorAction(DataSource ds) {
		this.ds = ds;
	}

	@Override
	public Object execute(Object o) {
		
		LowLevelContextMonitorArgument Log = new LowLevelContextMonitorArgument();

		String t = null;
		String PerceptionJsonData = null;

		saveGraph("/home/kist/DemoWorkspace/ContextManager/perceptionGraph.owl");
		lowLevelContextMonitor(Log);
		
		removeData();
		PerceptionJsonData = convertOwl2Json(Log);
		Log.toString();
		
		return "WebData Sended";
	}
	
	public void saveGraph(String filepath) {
		String getGraphData = "rdf_save('"+filepath+"', [graph(perception)]).";
		Query q = new Query(getGraphData);
		System.out.println(q.hasSolution()?"save graph succeeded":"save graph failed");
		//System.out.println("What sould OOOO do!");
//		SD.LCMD.filepath = filepath;		//knowrob path
	}

 
	public void lowLevelContextMonitor(LowLevelContextMonitorArgument log) {
		
		int count = 0;
				

		//System.out.println("What sould I do!");
		String getGraphDatatriples = null;
		int tripleNum = 0;
		getGraphDatatriples = "rdf(S,P,O,perception).";
		Query q = new Query(getGraphDatatriples);
		Map<String, Term>[] Obj = q.allSolutions();
//		System.out.println("Datatriples: "+Obj.length);
		tripleNum = Obj.length;
		//System.out.println("getGraphDataTriple: "+tripleNum);
//		System.out.println("What sould I do!");
		SD.LCMD.triples = Integer.toString(tripleNum);
//		System.out.println(tripleNum);
//		System.out.println(SD.LCMD.triples);
		
		log.setLCMtriples(SD.LCMD.triples);

//		System.out.println(Log.getLCMtriples());
		
		
		
		String getGraphDataObject = null;
		getGraphDataObject = "rdf(ObjectPerception, 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://knowrob.org/kb/knowrob.owl#VisualObjectPerception',perception).";
		Query q1 = new Query(getGraphDataObject);
		Map<String, Term>[] Obj1 = q1.allSolutions();
		
		//System.out.println("What sould II do!"+Obj1.length);
		//System.out.println("getGraphDataObject:"+count);
		
		SD.LCMD.objectperception = Integer.toString((int) Obj1.length);
		log.setLCMobjectPerception(SD.LCMD.objectperception);
		
		count=0;
		
		String getGraphDataRobot = null;
		getGraphDataRobot = "(rdfs_individual_of(RobotPerception, 'http://knowrob.org/kb/knowrob.owl#Proprioception');rdfs_individual_of(RobotPerception, 'http://knowrob.org/kb/knowrob.owl#VisualRobotPerception')),(rdf(RobotPerception,_,_,perception);rdf(_,_,RobotPerception,perception)).";
		q = new Query(getGraphDataRobot);
		
		while (q.hasMoreSolutions()) {
			q.nextSolution();
			count++;
		}
		
		//System.out.println("What sould III do!");
		
		//System.out.println("getGraphDataRobot:"+count);
		SD.LCMD.robotperception = Integer.toString((int) count);
		log.setLCMrobotPerception(SD.LCMD.robotperception);
		
		count=0;
		
		String getGraphDataHuman = null;
		getGraphDataHuman = "rdf(HumanPerception, 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://knowrob.org/kb/knowrob.owl#VisualHumanPerception',perception),(rdf(HumanPerception,_,_,perception);rdf(_,_,HumanPerception,perception)).";
		q = new Query(getGraphDataHuman);
		
		while (q.hasMoreSolutions()) {
			q.nextSolution();
			count++;
		}
		
		//System.out.println("What sould IIII do!");
		//System.out.println("getGraphDataHuman:"+count);

		SD.LCMD.humanperception = Integer.toString((int) count);
		log.setLCMhumanPerception(SD.LCMD.humanperception);
	}

	
	
	
	
	///////////////////////////graph data OWL to JSON
	
	
	
	public void removeData() {			//graph ==1: knowrob, graph ==2 :perception graph
		
		
		File file = null;
		String inputfile = null;
		
		inputfile = "/home/kist/DemoWorkspace/ContextManager/perceptionGraph.owl";
		file = new File(inputfile);
		String texts = "";

		try {
			if (checkBeforeFile(file)) {
				// FileReader를 인자로 하는 BufferedReader 객체 생성
				BufferedReader br = new BufferedReader(new FileReader(file));

				// 파일을 한 문장씩 읽어온다.
				String str = "";

				// EOF는 null문자를 포함하고 있다.
				while (str != null) {
					// 읽은 문자열을 출력한다.
					// System.out.println(str);
					// 다음 문자열을 가르켜준다.
					str = br.readLine();
					if (str == null) {
						break;
					}
					// System.out.println(str);
					if (str.contains("<owl:imports rdf:resource=\"package://knowrob_common/owl/rdf-schema.xml\"/>"))
						str = "";
					else if (str.contains("<owl:imports rdf:resource=\"package://knowrob_common/owl/knowrob.owl\"/>"))
						str = "";

					texts += str;
//					System.out.println(texts);
				}
				// FileReader와는 다르게 사용 후 꼭 닫아주어야 한다.
				
				System.out.println("after vr.close");
				try {
					////////////////////////////////////////////////////////////////
					BufferedWriter out = null;
					String outfile = null;
					
					outfile = "./perceptionGraph_temp.owl";
					
					out = new BufferedWriter(new FileWriter(outfile));
					// System.out.println(texts);
					String temp_texts = texts.substring(texts.length() - 4, texts.length());
					// System.out.println(temp_texts);
					if (temp_texts.contentEquals("null")) {
						texts = texts.substring(0, texts.length() - 4);
//						 System.out.println(texts);
					}
					out.write(texts);
//					System.out.println(texts);
					out.newLine();

					out.close();
					////////////////////////////////////////////////////////////////
				} catch (IOException e) {
					System.err.println(e);return ; // 에러가 있다면 메시지 출력
				}
				
				br.close();
			} else {
				System.out.println("파일에 접근할 수 없습니다.");
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();return ;
		} catch (IOException e) {
			e.printStackTrace();return ;
		}
	}
	
	

	public String convertOwl2Json(LowLevelContextMonitorArgument log) {		//graph ==1: knowrob, graph ==2 perception graph
		
		InputStream inputstream=null;
        OutputStream outputstream=null;
        
		final OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
		OWLOntology ontology = null;

		
		OWLDocumentFormat ontologyFormat = new RDFJsonDocumentFormat();
		OWLXMLDocumentFormat ontologyOwlFormat = new OWLXMLDocumentFormat();
		
		String OutFile = null;
		String InputOwlFile = null;
		
		OutFile = "./perceptionGraph.json";
		try {
			
			InputOwlFile = "./perceptionGraph_temp.owl";
			ontology = manager.loadOntologyFromOntologyDocument(new File(InputOwlFile));
				
		} catch (OWLOntologyCreationException e1) {
			// TODO Auto-generated catch block
			System.out.println("error occured in load");
			e1.printStackTrace();return "";
		}
		try {
			OutputStream out = new FileOutputStream(OutFile);
			manager.saveOntology( ontology, ontologyFormat, out);
		} catch (OWLOntologyStorageException e) {
			// TODO Auto-generated catch block
			System.out.println("error occured in save");
			e.printStackTrace();return "";
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();return "";
		}
		
	
		
		//JSON parser object to parse read file
        JSONParser jsonParser = new JSONParser();
        String inputJsonName = null;
        
        inputJsonName = "./perceptionGraph.json";
		
        try (FileReader reader = new FileReader(inputJsonName))
        {
            //Read JSON file
        	Object obj = jsonParser.parse(reader);
        	String jsonText = obj.toString();
//        	System.out.println(jsonText);
        	
        	log.setLCMgraph(jsonText);
//        	
//        	System.out.println("jsonTexted");
        	//ds.assertFact(jsonText);
        	return jsonText;
 
        } catch (FileNotFoundException e) {
            e.printStackTrace();return "";
        } catch (IOException e) {
            e.printStackTrace();return "";
        } catch (org.json.simple.parser.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return "";
		
	}
	static boolean checkBeforeFile(File file) {
		// 파일이 존재하고
		if (file.exists()) {
			// 그 파일이 파일이고, 읽을 수 있다면 true를 리턴한다.
			if (file.isFile() && file.canRead()) {
				return true;
			}
		}
		return false;
	}
	
	
	
	
	
	
}





