package kgu.agent.demo.action.webdataformat;

public class SharedData{
	public ContextOntologyMonitor COMD = new ContextOntologyMonitor();
	public LowLevelContextMonitor LCMD = new LowLevelContextMonitor();
}