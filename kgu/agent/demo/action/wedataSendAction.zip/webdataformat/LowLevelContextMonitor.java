package kgu.agent.demo.action.webdataformat;


public class LowLevelContextMonitor{
	public String filepath;
	public String triples;
	public String objectperception;
	public String robotperception;
	public String humanperception;
}