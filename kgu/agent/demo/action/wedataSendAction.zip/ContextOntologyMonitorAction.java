package kgu.agent.demo.action;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.Integer;
import java.util.Hashtable;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;

import jpl.*;
import org.json.simple.parser.JSONParser;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.formats.OWLXMLDocumentFormat;
import org.semanticweb.owlapi.formats.RDFJsonDocumentFormat;
import org.semanticweb.owlapi.model.OWLDocumentFormat;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.OWLOntologyStorageException;

import kgu.agent.demo.actionArgument.ContextOntologyMonitorArgument;
import kgu.agent.demo.actionArgument.WorkingMemory_MonitorsArgument;
import kr.ac.uos.ai.arbi.agent.logger.ActionBody;
import kr.ac.uos.ai.arbi.ltm.DataSource;
import kr.ac.uos.ai.arbi.model.GLFactory;
import kr.ac.uos.ai.arbi.model.GeneralizedList;
import kr.ac.uos.ai.arbi.model.parser.ParseException;
import kgu.agent.demo.agent.ContextManager;

import kgu.agent.demo.action.webdataformat.SharedData;

public class ContextOntologyMonitorAction implements ActionBody{

	
	public static final String JMS_BROKER_URL = "tcp://127.0.0.1:61616";
	public static final String TM_ADDRESS = "agent://www.arbi.com/taskManager";
	public static final String KM_ADDRESS = "agent://www.arbi.com/knowledgeManager";
	public static final String DC_URL = "dc://testWebDataSendCM";
	private DataSource ds;

	SharedData SD = new SharedData();
	
	
	public ContextOntologyMonitorAction(DataSource ds) {
		this.ds = ds;
		this.SD.COMD.filepath = "/home/kist/DemoWorkspace/ContextManager/knowrob_library/knowrob.owl";		//perception graph saved path
	}

	@Override
	public Object execute(Object o) {
		
		ContextOntologyMonitorArgument Log = new ContextOntologyMonitorArgument();
		//String sender = Log.getSender();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

		String t = null;
		String PerceptionJsonData = null;
		String OwlJsonData = null;

		contextOntologyMonitor(Log);
		
		removeData();
		convertOwl2Json(Log);
		Log.toString();
		
		return "WebData Sended";
	}

	
	public void contextOntologyMonitor(ContextOntologyMonitorArgument log) {
		

		String getGraphDataEdge = null;
		int tripleNum = 0;
		getGraphDataEdge = "rdf(S,P,O,'file:///home/kist/DemoWorkspace/ContextManager/knowrob_library/knowrob.owl').";
		Query q = new Query(getGraphDataEdge);
		Map<String, Term>[] Obj = q.allSolutions();

		tripleNum = Obj.length;
		//System.out.println("getGraphDataTriple: "+tripleNum);
		
		
		SD.COMD.triples = Integer.toString(tripleNum);
		log.setCOMtriples(SD.COMD.triples);
		
		
		HashSet ClassSet = new HashSet();
		String Classes = null;
		Classes = "(rdf(_,'http://www.w3.org/2000/01/rdf-schema#subClassOf',S,'file:///home/kist/DemoWorkspace/ContextManager/knowrob_library/knowrob.owl');rdf(S,'http://www.w3.org/2000/01/rdf-schema#subClassOf',_,'file:///home/kist/DemoWorkspace/ContextManager/knowrob_library/knowrob.owl')).";

		q = new Query(Classes);
		Map<String, Term>[] t = q.allSolutions();
		for(int i=0; i<t.length;i++) {
			ClassSet.add(t[i].get("S").toString());
		}
		//System.out.println("getGraphClasses:"+ClassSet.size());
		//System.out.println("Classes:"+ClassSet);
		
		
		SD.COMD.classes = Integer.toString(ClassSet.size());
		log.setCOMclasses(SD.COMD.classes);
		
		
		
		HashSet individualSet = new HashSet();
		String getGraphDataIndividual = null;
		getGraphDataIndividual = "rdf_reachable(S,'http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#NamedIndividual'),rdf(S,_,_,'file:///home/kist/DemoWorkspace/ContextManager/knowrob_library/knowrob.owl').";
		q = new Query(getGraphDataIndividual);
		
		Map<String, Term>[] s = q.allSolutions();
		for(int i=0; i<s.length;i++) {
			individualSet.add(s[i].get("S").toString());
		}
		//System.out.println("getGraphDataIndividual:"+individualSet.size());
		
		SD.COMD.individuals = Integer.toString(individualSet.size());
		log.setCOMindividuals(SD.COMD.individuals);
	
	
		HashSet objectPropertySet = new HashSet();
		String getGraphDataObjectProperty = null;
		getGraphDataObjectProperty = "rdf_reachable(P, 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#ObjectProperty'),rdf(P,_,_,'file:///home/kist/DemoWorkspace/ContextManager/knowrob_library/knowrob.owl').";
		q = new Query(getGraphDataObjectProperty);
		
		Map<String, Term>[] w = q.allSolutions();
			
		for(int i=0; i<w.length;i++) {
			objectPropertySet.add(w[i].get("P").toString());
		}
		System.out.println("getGraphDataObjectProperty:"+objectPropertySet.size());
		
		SD.COMD.objectProperties= Integer.toString(objectPropertySet.size());
		log.setCOMobjectproperties(SD.COMD.objectProperties);
		
		
		
		HashSet dataPropertySet = new HashSet();
		String getGraphDataDataProperty = null;
		getGraphDataDataProperty = "rdf_reachable(P, 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#DatatypeProperty'),rdf(P,_,_,'file:///home/kist/DemoWorkspace/ContextManager/knowrob_library/knowrob.owl').";
		q = new Query(getGraphDataDataProperty);
		
		Map<String, Term>[] l = q.allSolutions();
		
		for(int i=0; i<l.length;i++) {
			dataPropertySet.add(l[i].get("P").toString());
		}
		//System.out.println("getGraphDataDataProperty:"+dataPropertySet.size());
		
		SD.COMD.datatypeProperties = Integer.toString(dataPropertySet.size());
		log.setCOMdatatypeproperties(SD.COMD.datatypeProperties);
		
	}
	
	
	
	
	///////////////////////////graph data OWL to JSON
	
	
	
	public void removeData() {			//graph ==1: knowrob, graph ==2 :perception graph
		
		
		File file = null;
		String inputfile = null;
		
		inputfile = "/home/kist/DemoWorkspace/ContextManager/knowrob_library/knowrob.owl";
		//System.out.println("are you oK?");
		file = new File(inputfile);
		String texts = "";

		try {
			if (checkBeforeFile(file)) {
				// FileReader를 인자로 하는 BufferedReader 객체 생성
				BufferedReader br = new BufferedReader(new FileReader(file));

				// 파일을 한 문장씩 읽어온다.
				String str = "";

				// EOF는 null문자를 포함하고 있다.
				while (str != null) {
					// 읽은 문자열을 출력한다.
					// System.out.println(str);
					// 다음 문자열을 가르켜준다.
					str = br.readLine();
					if (str == null) {
						break;
					}
					// System.out.println(str);
					if (str.contains("<owl:imports rdf:resource=\"package://knowrob_common/owl/rdf-schema.xml\"/>"))
						str = "";
					else if (str.contains("<owl:imports rdf:resource=\"package://knowrob_common/owl/knowrob.owl\"/>"))
						str = "";

//					if (str == null || str.contentEquals("null"))
//						break;

					texts += str;
//					System.out.println(texts);
				}
				// FileReader와는 다르게 사용 후 꼭 닫아주어야 한다.
				
				System.out.println("after vr.close");
//				System.out.println(texts);
				try {
					////////////////////////////////////////////////////////////////
					BufferedWriter out = null;
					String outfile = null;
					
					outfile = "./knowrob.owl";
					
					out = new BufferedWriter(new FileWriter(
							outfile));
					// System.out.println(texts);
					String temp_texts = texts.substring(texts.length() - 4, texts.length());
					// System.out.println(temp_texts);
					if (temp_texts.contentEquals("null")) {
						texts = texts.substring(0, texts.length() - 4);
//						 System.out.println(texts);
					}
					out.write(texts);
//					System.out.println(texts);
					out.newLine();

					out.close();
					////////////////////////////////////////////////////////////////
				} catch (IOException e) {
					System.err.println(e);return ; // 에러가 있다면 메시지 출력
				}
				
				br.close();
			} else {
				System.out.println("파일에 접근할 수 없습니다.");
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();return ;
		} catch (IOException e) {
			e.printStackTrace();return ;
		}

		

	}

	public String convertOwl2Json(ContextOntologyMonitorArgument log) {		//graph ==1: knowrob, graph ==2 perception graph
		
		InputStream inputstream=null;
        OutputStream outputstream=null;
        
		final OWLOntologyManager manager = OWLManager.createOWLOntologyManager();
		OWLOntology ontology = null;

		
		OWLDocumentFormat ontologyFormat = new RDFJsonDocumentFormat();
		OWLXMLDocumentFormat ontologyOwlFormat = new OWLXMLDocumentFormat();
		
		String OutFile = null;
		String InputOwlFile = null;
		
		OutFile = "./knowrob.json";
		try {
			
			
			InputOwlFile = "./knowrob.owl";
			
			ontology = manager.loadOntologyFromOntologyDocument(new File(InputOwlFile));
				
		} catch (OWLOntologyCreationException e1) {
			// TODO Auto-generated catch block
			System.out.println("error occured in load");
			e1.printStackTrace();return "";
		}
		try {
			OutputStream out = new FileOutputStream(OutFile);
			manager.saveOntology( ontology, ontologyFormat, out);
		} catch (OWLOntologyStorageException e) {
			// TODO Auto-generated catch block
			System.out.println("error occured in save");
			e.printStackTrace();return "";
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();return "";
		}
		
	
		
		//JSON parser object to parse read file
        JSONParser jsonParser = new JSONParser();
        String inputJsonName = null;
        
        inputJsonName = "./knowrob.json";
		
        try (FileReader reader = new FileReader(inputJsonName))
        {
            //Read JSON file
        	Object obj = jsonParser.parse(reader);
        	String jsonText = obj.toString();
//        	System.out.println(jsonText);
        	
     
        	log.setCOMgraph(jsonText);
//        	System.out.println("jsonTexted");
        	//ds.assertFact(jsonText);
        	return jsonText;
 
        } catch (FileNotFoundException e) {
            e.printStackTrace();return "";
        } catch (IOException e) {
            e.printStackTrace();return "";
        } catch (org.json.simple.parser.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return "";
		
	}
	static boolean checkBeforeFile(File file) {
		// 파일이 존재하고
		if (file.exists()) {
			// 그 파일이 파일이고, 읽을 수 있다면 true를 리턴한다.
			if (file.isFile() && file.canRead()) {
				return true;
			}
		}
		return false;
	}
	
	
	
	
	
	
}





