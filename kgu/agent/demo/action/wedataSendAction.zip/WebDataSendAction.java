package kgu.agent.demo.action;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;

import org.json.simple.parser.JSONParser;

import kgu.agent.demo.action.webdataformat.SharedData;
import kgu.agent.demo.actionArgument.WebDataArgument;
import kgu.agent.demo.actionArgument.WorkingMemory_MonitorsArgument;
import kr.ac.uos.ai.arbi.agent.logger.ActionBody;
import kr.ac.uos.ai.arbi.agent.logger.AgentAction;
import kr.ac.uos.ai.arbi.agent.logger.LogTiming;
import kr.ac.uos.ai.arbi.agent.logger.LoggerManager;
import kr.ac.uos.ai.arbi.ltm.DataSource;
import kr.ac.uos.ai.arbi.model.GLFactory;
import kr.ac.uos.ai.arbi.model.GeneralizedList;
import kr.ac.uos.ai.arbi.model.parser.ParseException;
import kgu.agent.demo.agent.ContextManager;

public class WebDataSendAction extends Thread {
	
	public AgentAction LowLevelContextMonitorAction;
	public AgentAction ContextOntologyMonitorAction;
	private DataSource ds;

	public WebDataSendAction(DataSource ds) {
		this.ds = ds;
		this.LowLevelContextMonitorAction = new AgentAction("LowLevelContextMonitorAction", new LowLevelContextMonitorAction(ds));
		LoggerManager.getInstance().registerAction( LowLevelContextMonitorAction, LogTiming.Later);
		this.ContextOntologyMonitorAction = new AgentAction("ContextOntologyMonitorAction", new ContextOntologyMonitorAction(ds));
		LoggerManager.getInstance().registerAction( ContextOntologyMonitorAction, LogTiming.Later);
	}

	public void run() {
		while (true) {
			try {
				Thread.sleep(10000);

				System.out.println("before execute");
				Object argument1 = null;
				Object argument2 = null;
				LowLevelContextMonitorAction.execute(argument1);
				ContextOntologyMonitorAction.execute(argument2);
				System.out.println("after execute");
				
			} catch (ArrayIndexOutOfBoundsException e) {
				System.err.println("errored in Webdatasend thread: ArrayIndexOutOfBounds");
				System.out.println("doing exception 1");
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				System.out.println("doing exception 2");
				System.err.println("errored in Webdatasend thread: InterruptedException --> caused by sleep");
				e.printStackTrace();
			}
		}
	}



}
