package kgu.agent.demo.action;


import kgu.agent.demo.action.GetGraphData;

public class LowLevelContextMonitor{
	public String filepath;
	public String triples;
	public String objectperception;
	public String robotperception;
	public String humanperception;
}