package kgu.agent.demo.action;


import kgu.agent.demo.action.GetGraphData;


public class ContextOntologyMonitor{
	public String filepath;
	public String triples;
	public String classes;
	public String individuals;
	public String objectProperties;
	public String datatypeProperties;
}