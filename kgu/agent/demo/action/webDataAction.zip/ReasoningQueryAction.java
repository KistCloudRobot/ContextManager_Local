package kgu.agent.demo.action;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import jpl.Query;
import jpl.Term;
import kgu.agent.demo.actionArgument.GLArgument;
import kgu.agent.demo.agent.ContextManager;
import kgu.agent.demo.paser.ContextQueryPaser;
import kr.ac.uos.ai.arbi.agent.logger.ActionBody;
import kr.ac.uos.ai.arbi.ltm.DataSource;
import kr.ac.uos.ai.arbi.model.Binding;
import kr.ac.uos.ai.arbi.model.BindingFactory;
import kr.ac.uos.ai.arbi.model.Expression;
import kr.ac.uos.ai.arbi.model.GLFactory;
import kr.ac.uos.ai.arbi.model.GeneralizedList;
import kr.ac.uos.ai.arbi.model.parser.ParseException;

public class ReasoningQueryAction implements ActionBody {
	private DataSource ds;
	private ContextManager cm;
	
	public ReasoningQueryAction(DataSource ds, ContextManager cm) {
		this.ds = ds;
		this.cm = cm;
	}
	
	@Override
	public Object execute(Object o) {
		GLArgument Log = (GLArgument) o;
		String queryToProlog;
		String queryResult = "";
		String responseOfPrologQuery = "";
		String queryToPrologAnswer = "";
		double time2 = 0;
		double time = 0;

		GeneralizedList gl = null;
		try {
			gl = GLFactory.newGLFromGLString(Log.getGL());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// String query = "(context (on_Physical $Top
		// \"http://www.arbi.com/ontologies/arbi.owl#table1\") (on_Physical
		// $Top2 \"http://www.arbi.com/ontologies/arbi.owl#table2\") )";
		String sumOfPrologQuery = "";
		String temp = prefixToURI(Log.getGL()).replaceAll("-", "_");
		String[] forVariable = temp.split("\\)|\\(| |\n|\t");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		
		System.out.println("gl: "+gl);
		//System.out.println(gl.getExpressionsSize());
		
		for (int k = 0; k < gl.getExpressionsSize();k++) {
			Expression e = gl.getExpression(k);
			GeneralizedList temp2 = e.asGeneralizedList();
			String predicate = temp2.getName();
			int tempSize = temp2.getExpressionsSize();
			
			String[] arg = new String[tempSize];
			for (int j = 0; j < tempSize; j++) {
				arg[j] = temp2.getExpression(j).toString();
			}
			//이쪽에서 서술자에 따라 parameter 수치를 수정해주시면 됩니다
			if (predicate.equals("reachableBasePose")) {
				String target = temp2.getExpression(1).toString();
				if(target.contains("juice") || target.contains("water")){
					queryResult = "(context (reachableBasePose "+ arg[0] +" "+ arg[1] +" \"-3.036 0.244 0.000 -0.071 0.997\"))";
					queryToPrologAnswer = "reachableBasePose("+ arg[0] +", "+ arg[1] +", \"-3.036 0.244 0.000 -0.071 0.997\")";
				}else {
					queryResult = "(context (reachableBasePose "+ arg[0] +" "+ arg[1] +" \"-2.040 -1.298 0.000  0.661 0.751\"))";
					queryToPrologAnswer = "reachableBasePose("+ arg[0] +", "+ arg[1] +", \"-2.040 -1.298 0.000  0.661 0.751\")";
				}
				break;
			}

			else if(predicate.equals("preGraspableHandPose")) {
				queryResult = "(context (preGraspableHandPose "+ arg[0] +" "+ arg[1]+" "+ arg[2] +" \"274 167 57 241 81 77\"))";
				queryToPrologAnswer = "(preGraspableHandPose("+ arg[0] +", "+ arg[1]+", "+ arg[2] +", \"274 167 57 241 81 77\")";
				break;
			}
		
			else if(predicate.equals("postGraspableHandPose")) {
				queryResult = "(context (postGraspableHandPose "+ arg[0] +" "+ arg[1]+" "+ arg[2] +" \"274 167 57 241 81 77\"))";
				queryToPrologAnswer = "postGraspableHandPose("+ arg[0] +", "+ arg[1]+", "+ arg[2] +", \"274 167 57 241 81 77\")";
				break;
			}
			else if(predicate.equals("graspableHandPose")) {
				queryResult = "(context (graspableHandPose "+ arg[0] +" "+ arg[1]+" "+ arg[2] +" \"192 219 124 256 41 72\"))";
				queryToPrologAnswer = "graspableHandPose("+ arg[0] +", "+ arg[1]+", "+ arg[2] +", \"192 219 124 256 41 72\")";
				break;
			}

			else if(predicate.equals("placeableBasePose")) {
				String target = temp2.getExpression(1).toString();
				if(target.contains("table")) {
					queryResult = "(context (placeableBasePose "+ arg[0] +" "+ arg[1] +" \"-2.040 -1.298 0.000  0.661 0.751\"))";
					queryToPrologAnswer = "placeableBasePose("+ arg[0] +", "+ arg[1] +", \"-2.040 -1.298 0.000  0.661 0.751\")";
				}else {
					queryResult = "(context (placeableBasePose "+ arg[0] +" "+ arg[1] +" \"-3.036 0.244 0.000 -0.071 0.997\"))";

					queryToPrologAnswer = "placeableBasePose("+ arg[0] +", "+ arg[1] +", \"-3.036 0.244 0.000 -0.071 0.997\")";
				}
				
				break;
			}
			else if(predicate.equals("lowerableHandPose")) {
				queryResult = "(context (lowerableHandPose "+ arg[0] +" "+ arg[1]+" "+ arg[2]+" "+ arg[3] +" \"1.232 2.498 0.399 3.598 0.474 2.324 0.954\" \"274 167 57 241 81 77\"))";
				queryToPrologAnswer = "lowerableHandPose ("+ arg[0] +", "+ arg[1]+", "+ arg[2]+", "+ arg[3] +", \"1.232 2.498 0.399 3.598 0.474 2.324 0.954\", \"274 167 57 241 81 77\")";
				
				break;
			}
																																					
			else if(predicate.equals("placeableHandPose")) {
				queryResult = "(context (graspableHandPose "+ arg[0] +" "+ arg[1]+" "+ arg[2] +" "+ arg[3] +" \"1.232 2.498 0.399 3.598 0.474 2.324 0.954\" \"192 219 124 256 41 72\"))";
				queryToPrologAnswer = "graspableHandPose("+ arg[0] +", "+ arg[1]+", "+ arg[2] +", "+ arg[3] +", \"1.232 2.498 0.399 3.598 0.474 2.324 0.954\", \"192 219 124 256 41 72\")";
				break;
			}
			else if(predicate.equals("placeableObjectPose")) {
				queryResult = "(context (graspableObjectPose "+ arg[0] +" "+ arg[1]+" \"1.232 2.498 0.399 3.598 0.474 2.324 0.954\" \"173 185 99 0 0 0 0\"))";
				queryToPrologAnswer = "graspableObjectPose("+ arg[0] +", "+ arg[1]+", \"1.232 2.498 0.399 3.598 0.474 2.324 0.954\", \"173 185 99 0 0 0 0\")";
				break;
			}																																		
			else if(predicate.equals("retractableHandPose")) {
				queryResult = "(context (retractableHandPose "+ arg[0] +" "+ arg[1]+" "+ arg[2] +" "+ arg[3] +" \"1.232 2.498 0.399 3.598 0.474 2.324 0.954\" \"274 167 57 241 81 77\"))";
				queryToPrologAnswer = "retractableHandPose("+ arg[0] +", "+ arg[1]+", "+ arg[2] +", "+ arg[3] +", \"1.232 2.498 0.399 3.598 0.474 2.324 0.954\", \"274 167 57 241 81 77\")";
				
				break;
			}
//			else if(predicate.equals("drink")) {
//				if(arg[0].contains("Person001")) {
//					queryResult = "(context (drink "+arg[0]+" \"\" \"TODAY\"))";
//					break;
//				}
//				else if(arg[0].contains("Person002")) {
//					System.out.println("dummy");
//					queryResult = "(context (drink "+arg[0]+" \"http://robot-arbi.kr/ontologies/complexService.owl#Coffee001\" \"TODAY\"))";
//					break;
//				}
//			}	
		
		if(!predicate.equals("reachableBasePose") || !predicate.equals("preGraspableHandPose") || !predicate.equals("postGraspableHandPose") || !predicate.equals("placeableBasePose")|| !predicate.equals("graspableHandPose")||!predicate.equals("lowerableHandPose")||!predicate.equals("placeableObjectPose") || !predicate.equals("placeableHandPose") || !predicate.equals("retractableHandPose")) {
		//GL to PL 바꿔주는 부분 (나중에 모듈화 필요)
		for (int i = 0; i < gl.getExpressionsSize(); i++) {

			//Expression e = gl.getExpression(i);
			e = gl.getExpression(i);
			//GeneralizedList temp2 = e.asGeneralizedList();
			temp2 = e.asGeneralizedList();

			//int tempSize = temp2.getExpressionsSize();
			tempSize = temp2.getExpressionsSize();

			//String predicate = temp2.getName();
			predicate = temp2.getName();
			String prologQuery = predicate + "(";
			String[] arg2 = new String[tempSize];
			
			
			for (int j = 0; j < tempSize; j++) {

				long startTimeEpoch = 0;
				Date startTime = null;

				arg2[j] = temp2.getExpression(j).toString();

				if (arg2[j].contains("$")) {
					arg2[j] = arg2[j].substring(1, arg2[j].length());
					prologQuery += "" + arg2[j] + ", ";

				} else {
					arg2[j] = arg2[j].substring(1, arg2[j].length() - 1);
					
					try {
						startTime = sdf.parse(arg2[j]);
						startTimeEpoch = startTime.getTime() / 1000;
						arg2[j] = "http://www.arbi.com/ontologies/arbi.owl#timepoint_" + startTimeEpoch;
					} catch (java.text.ParseException e2) {}
		
					prologQuery += "'" + arg2[j] + "', ";

				} if (j + 1 == temp2.getExpressionsSize()) {
					prologQuery = prologQuery.substring(0, prologQuery.length() - 2);
					prologQuery += ")";
				}
			}
			
			System.out.println("prolog Query: "+prologQuery);

			if (i + 1 == gl.getExpressionsSize()) {
				sumOfPrologQuery += prologQuery + ".";
			}else {
				sumOfPrologQuery += prologQuery + ", ";
			}
		}
		System.out.println("Trans to Prolog Query : "+sumOfPrologQuery);
		
		Log.setQuery(sumOfPrologQuery);
		
		time = System.currentTimeMillis();
		
		////////////////////////////////////////////////////// 추론 시작
		Query q = new Query(sumOfPrologQuery);
		String temp3 =null;
		while (q.hasMoreSolutions()) {
			// 질의에 대한 결과가 있는 경우
			temp3 = temp;
			Map<String, Term> s3 = q.nextSolution();
			
			System.out.println("Map length :"+forVariable.length);

			for (int l = 0; l < forVariable.length; l++) {
				
				System.out.println("forVariable[l] :" + forVariable[l]);
				
				if (forVariable[l].contains("$")) {
					String variable = forVariable[l].substring(1);
					String answer = s3.get(variable).toString();
					System.out.println("answer :" + answer);
					
					if(answer.contains("[]")) {
						answer = answer.replace("(", "").replace(")", "").replace("[]", "").replace("'.'", "").replace(",", "");
						
						temp3 = temp3.replace("$"+variable,answer);
						System.out.println("temp322222 : "+temp3);
						System.out.println("answer is : "+answer);
						continue;
					}
					answer = answer.replace("'", "\"");
					if (!answer.contains("\""))
						answer = "\"" + answer + "\"";
					temp3 = temp3.replace("$" + variable, answer);
					System.out.println("temp3 : "+temp3);
					System.out.println("answer is : "+answer);
					
					responseOfPrologQuery = temp3;
					responseOfPrologQuery = responseOfPrologQuery.substring(responseOfPrologQuery.indexOf("(",1), responseOfPrologQuery.length()-1);
					responseOfPrologQuery = responseOfPrologQuery.substring(responseOfPrologQuery.indexOf("(")+1, responseOfPrologQuery.length()-1);
					String Words1[] = responseOfPrologQuery.split(" ");
					responseOfPrologQuery = Words1[0]+"(";
					for (int t=1 ; t< Words1.length; t++) {
						if(t == Words1.length-1)
							responseOfPrologQuery = responseOfPrologQuery + Words1[t];
						else
							responseOfPrologQuery = responseOfPrologQuery + Words1[t]+", ";
					}
					responseOfPrologQuery = responseOfPrologQuery+")";
//					System.out.println("responseOfPrologQuery: "+responseOfPrologQuery);
				}

				// System.out.println(s3.toString());

			}

			// System.out.println(s3.toString());
			queryResult += temp3 + "\n";
			queryToPrologAnswer += responseOfPrologQuery + "\n";
			System.out.println("responseOfPrologQuery: "+responseOfPrologQuery);
		}
		
		if(temp3==null) {
			// 질의에 대한 결과가 없는 경우
			temp3 = temp;
			for (int l = 0; l < forVariable.length; l++) {
				if (forVariable[l].contains("$")) {
					String variable = forVariable[l].substring(1);
					temp3 = temp3.replace("$" + variable, "\"\"");
					System.out.println("temp3-- : "+temp3);
				}
			}
			responseOfPrologQuery = temp3;
			responseOfPrologQuery = responseOfPrologQuery.substring(responseOfPrologQuery.indexOf("(",1), responseOfPrologQuery.length()-1);
			responseOfPrologQuery = responseOfPrologQuery.substring(responseOfPrologQuery.indexOf("(")+1, responseOfPrologQuery.length()-1);
			String Words1[] = responseOfPrologQuery.split(" ");
			responseOfPrologQuery = Words1[0]+"(";
			for (int t=1 ; t< Words1.length; t++) {
				if(t == Words1.length-1)
					responseOfPrologQuery = responseOfPrologQuery + Words1[t];
				else
					responseOfPrologQuery = responseOfPrologQuery + Words1[t]+", ";
			}
			responseOfPrologQuery = responseOfPrologQuery+")";
		
			
			
			queryResult += temp3 + "\n";
			queryToPrologAnswer += responseOfPrologQuery + "\n";
		}
		}}
		
		time2 = System.currentTimeMillis();
		System.out.println("This is query result : "+queryResult);
		
		Log.setResponser("dc://CM");
		Log.setResponseGL(queryResult);
		Log.setSpentTime(time2-time);
		Log.setQuery(responseOfPrologQuery);
		if(!queryResult.contains("\"\"")) {
			ds.assertFact(queryResult);
		}
		
		
		
		String thisTime = String.valueOf(System.currentTimeMillis());
		String dataToSend = "(SystemLog (actor \"contextManager\") (type \"ContextService\") "
				+ "(action \"queryContext\") (content \""+ Log.toString() +"\") (time \""+ thisTime +"\"))";
		cm.send("agent://www.arbi.com/interactionManager",dataToSend);
		//ds.assertFact(dataToSend);
		return queryResult;
	}
	
	
	public static String literalConversion(String s) {
		if (s.contains("'")) {
			s = s.split("'")[1];
			if (s.equalsIgnoreCase("true") || s.equalsIgnoreCase("false")) {
				s = "literal(type('http://www.w3.org/2001/XMLSchema#boolean', " + s + "))";
			} else {
				s = "literal(type('http://www.w3.org/2001/XMLSchema#double', '" + s + "'))";
			}
		} else if (s.contains("\"")) {
			s = s.split("\"")[1];
			s = "literal(type('http://www.w3.org/2001/XMLSchema#string', '" + s + "'))";
		}

		return s;
	}

	public static String prefixToURI(String s) {

		s = s.replaceAll("rdf:", "http://www.w3.org/1999/02/22-rdf-syntax-ns#");
		s = s.replaceAll("knowrob:", "http://knowrob.org/kb/knowrob.owl#");
		s = s.replaceAll("arbi:", "http://www.arbi.com/ontologies/arbi.owl#");
		s = s.replaceAll("robot:", "http://knowrob.org/kb/jaco.owl#");

		s = "" + s + "";

		return s;
	}

	public static String URIToPrefix(String s) {

		s = s.replaceAll("http://www.w3.org/1999/02/22-rdf-syntax-ns#", "rdf:");
		s = s.replaceAll("http://knowrob.org/kb/knowrob.owl#", "knowrob:");
		s = s.replaceAll("http://www.arbi.com/ontologies/arbi.owl#", "arbi:");
		s = s.replaceAll("http://knowrob.org/kb/jaco.owl#", "robot:");

		return s;
	}

}