//package kgu.agent.demo.action;
//
//import java.text.SimpleDateFormat;
//import java.util.Date;
//import java.util.Hashtable;
//import java.util.Map;
//import java.util.Scanner;
//import kr.ac.uos.ai.arbi.agent.ArbiAgent;
//import kr.ac.uos.ai.arbi.agent.ArbiAgentExecutor;
//import kr.ac.uos.ai.arbi.agent.logger.AgentAction;
//import kr.ac.uos.ai.arbi.agent.logger.LogTiming;
//import kr.ac.uos.ai.arbi.agent.logger.LoggerManager;
//import kr.ac.uos.ai.arbi.ltm.DataSource;
//import kr.ac.uos.ai.arbi.agent.*;
//import org.omg.CORBA.Request;
//
//import org.jpl7.*;
//import kgu.agent.demo.actionArgument.GLArgument;
//import kgu.agent.demo.actionArgument.WorkingMemory_MonitorsArgument;
//import kr.ac.uos.ai.arbi.agent.logger.ActionBody;
//import kr.ac.uos.ai.arbi.model.GLFactory;
//import kr.ac.uos.ai.arbi.model.GeneralizedList;
//import kr.ac.uos.ai.arbi.model.parser.ParseException;
//import kgu.agent.demo.agent.ContextManager;
//
//public class GetGraphDataAction {
//	
//	public void saveGraph(String filepath) {
//		String getGraphData = "rdf_save_db('"+filepath+"', perception).";
//		Query q = new Query(getGraphData);
//		System.out.println(q.hasSolution()?"save graph succeeded":"save graph failed");
//	}
//	public void loadGraph(String filepath) {
//		String getGraphData = "rdf_load_db('"+filepath+"').";
//		Query q = new Query(getGraphData);
//		System.out.println(q.hasSolution()?"load graph succeeded":"load graph failed");
//		
//		
//		String getGraphName = "rdf_graph(Graph).";
//		Query t = new Query(getGraphName);
//		while (t.hasMoreSolutions()) {
//			Map<String, Term> s = t.nextSolution();
//			
//				System.out.println("s :"+s);
//	
//				for (int l = 0; l < s.size(); l++) {
//					System.out.println("s.values :"+s.values());
//				}
//	
//		}
//		System.out.println("load==================================");
//	}
//	public void countGraphData(String filepath) {
//		
//		long count = 0;
//		
////		String dummyData = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#visualRobotPerception001', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://knowrob.org/kb/knowrob.owl#VisualRobotPerception').";
////		System.out.println(Query.hasSolution(dummyData) ? "Succeeded":"Failed");
////		dummyData = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#proprioception001', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://knowrob.org/kb/knowrob.owl#Proprioception').";
////		System.out.println(Query.hasSolution(dummyData) ? "Succeeded":"Failed");
//		
//		String getGraphName = "rdf_graph(Graph).";
//		Query t = new Query(getGraphName);
//		while (t.hasMoreSolutions()) {
//			Map<String, Term> s = t.nextSolution();
//			
//				System.out.println("s :"+s);
//	
//				for (int l = 0; l < s.size(); l++) {
//					System.out.println("s.values :"+s.values());
//				}
//	
//		}
//		
//		String getGraphDataEdge = null;
//		if(filepath.contentEquals("")) getGraphDataEdge = "rdf(_,P,_,perception).";
//		else getGraphDataEdge = "rdf(_,P,_,'"+filepath+"').";
//		Query q = new Query(getGraphDataEdge);
//		Hashtable[] Obj = q.allSolutions();
//		System.out.println("getGraphDataTriples:"+Obj.length);
//		
//		
//		String getGraphDataObject = null;
//		if(filepath.contentEquals("")) getGraphDataObject = "not(rdf(ObjectPerception, 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://knowrob.org/kb/knowrob.owl#Hand',perception)),rdf(ObjectPerception, 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://knowrob.org/kb/knowrob.owl#VisualObjectPerception',perception),(rdf(ObjectPerception,_,_,perception);rdf(_,_,ObjectPerception,perception)).";
//		else getGraphDataObject = "not(rdf(ObjectPerception, 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://knowrob.org/kb/knowrob.owl#Hand','"+filepath+"')),rdf(ObjectPerception, 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://knowrob.org/kb/knowrob.owl#VisualObjectPerception','"+filepath+"'),(rdf(ObjectPerception,_,_,'"+filepath+"');rdf(_,_,ObjectPerception,'"+filepath+"')).";
//		q = new Query(getGraphDataObject);
//		while (q.hasMoreSolutions()) {
//			q.nextSolution();
//			count++;
//		}
//		System.out.println("getGraphDataObject:"+count);
//		count=0;
//		
//		
//		String getGraphDataRobot = null;
//		if(filepath.contentEquals("")) getGraphDataRobot = "(rdfs_individual_of(RobotPerception, 'http://knowrob.org/kb/knowrob.owl#Proprioception');rdfs_individual_of(RobotPerception, 'http://knowrob.org/kb/knowrob.owl#VisualRobotPerception')),(rdf(RobotPerception,_,_,perception);rdf(_,_,RobotPerception,perception)).";
//		else getGraphDataRobot = "(rdfs_individual_of(RobotPerception, 'http://knowrob.org/kb/knowrob.owl#Proprioception');rdfs_individual_of(RobotPerception, 'http://knowrob.org/kb/knowrob.owl#VisualRobotPerception')),(rdf(RobotPerception,_,_,'"+filepath+"');rdf(_,_,RobotPerception,'"+filepath+"')).";
//		q = new Query(getGraphDataRobot);
//		
//		while (q.hasMoreSolutions()) {
//			q.nextSolution();
//			count++;
//		}
//		System.out.println("getGraphDataRobot:"+count);
//		count=0;
//		
//		
//		//String getGraphDataHuman = "setof(Human,(rdf(HumanPerception,rdf:type, 'http://knowrob.org/kb/knowrob.owl#VisualHumanPerception'),rdf(HumanPerception, 'http://knowrob.org/kb/knowrob.owl#objectActedOn', Human)),(rdf(Human,_,_,perception);rdf(_,_,Human,perception))),Humans).";
//		String getGraphDataHuman = null;
//		if(filepath.contentEquals("")) getGraphDataHuman = "rdf(HumanPerception, 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://knowrob.org/kb/knowrob.owl#VisualHumanPerception',perception),(rdf(HumanPerception,_,_,perception);rdf(_,_,HumanPerception,perception)).";
//		else getGraphDataHuman = "rdf(HumanPerception, 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://knowrob.org/kb/knowrob.owl#VisualHumanPerception','"+filepath+"'),(rdf(HumanPerception,_,_,'"+filepath+"');rdf(_,_,HumanPerception,'"+filepath+"')).";
//		q = new Query(getGraphDataHuman);
//		
//		while (q.hasMoreSolutions()) {
//			q.nextSolution();
//			count++;
//		}
//		System.out.println("getGraphDataHuman:"+count);
//
//		
//	}
//
//	public void contextOntologyMonitor(String filepath) {
//long count = 0;
//		
////		String dummyData = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#visualRobotPerception001', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://knowrob.org/kb/knowrob.owl#VisualRobotPerception').";
////		System.out.println(Query.hasSolution(dummyData) ? "Succeeded":"Failed");
////		dummyData = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#proprioception001', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://knowrob.org/kb/knowrob.owl#Proprioception').";
////		System.out.println(Query.hasSolution(dummyData) ? "Succeeded":"Failed");
//		
//		
//		
//		String getGraphDataEdge = null;
//		if(filepath.contentEquals("")) getGraphDataEdge = "rdf(_,P,_,perception).";
//		else getGraphDataEdge = "rdf(_,P,_,'"+filepath+"').";
//		Query q = new Query(getGraphDataEdge);
//		Hashtable[] Obj = q.allSolutions();
//		System.out.println("getGraphDataTriples:"+Obj.length);
//
//
////		,rdf_reachable(Type, 'http://www.w3.org/2000/01/rdf-schema#subClassOf', Object)
//		String Classes = null;
//		if(filepath.contentEquals("")) Classes = "setof(Type,"
//				+ "((rdf(S,_,_,perception);rdf(_,_,S,perception)),rdf(S,'http://www.w3.org/1999/02/22-rdf-syntax-ns#type',Type,perception))"
//				+ ",Classes).";
////				+ "length(Classes, Count).";
//		else Classes = "setof(rdf(S,_,_,'"+filepath+"'),rdf(S,rdf:type,Type),rdf_reachable(Type, 'http://www.w3.org/2000/01/rdf-schema#subClassOf', Object)).";
//		q = new Query(Classes);
//		Hashtable[] Obj1 = q.allSolutions();
//		System.out.println(Obj1[0]);
////		while (q.hasMoreSolutions()) {
////			Map<String, Term> s = q.nextSolution();
////			
////			System.out.println("s :"+s);
////
////			for (int l = 0; l < s.size(); l++) {
////				System.out.println("s.values :"+s.values());
////			}
////			count++;
////		}
////		System.out.println("getGraphDataObject:"+count);
////		count=0;
//		
//		
//		
//		
//		
//		String getGraphDataIndividual = null;
//		if(filepath.contentEquals("")) getGraphDataIndividual = "rdf(S, 'http://www.w3.org/2002/07/owl#NamedIndividual',O).";
//		else getGraphDataIndividual = "(rdfs_individual_of(RobotPerception, 'http://knowrob.org/kb/knowrob.owl#Proprioception');rdfs_individual_of(RobotPerception, 'http://knowrob.org/kb/knowrob.owl#VisualRobotPerception')),(rdf(RobotPerception,_,_,'"+filepath+"');rdf(_,_,RobotPerception,'"+filepath+"')).";
//		q = new Query(getGraphDataIndividual);
//		
//		while (q.hasMoreSolutions()) {
//			Map<String, Term> s = q.nextSolution();
//			
//			System.out.println("s :"+s);
//
//			for (int l = 0; l < s.size(); l++) {
//				System.out.println("s.values :"+s.values());
//			}
//			count++;
//		}
//		System.out.println("getGraphDataIndividual:"+count);
//		count=0;
//		
//		//, rdf_graph(G),rdf(P, 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://knowrob.org/kb/knowrob.owl#ObjectProperty',G)
//		//String getGraphDataHuman = "setof(Human,(rdf(HumanPerception,rdf:type, 'http://knowrob.org/kb/knowrob.owl#VisualHumanPerception'),rdf(HumanPerception, 'http://knowrob.org/kb/knowrob.owl#objectActedOn', Human)),(rdf(Human,_,_,perception);rdf(_,_,Human,perception))),Humans).";
//		String getGraphDataObjectProperty = null;
//		if(filepath.contentEquals("")) getGraphDataObjectProperty = "rdf(_, P, _,perception),rdf(P, 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://knowrob.org/kb/knowrob.owl#ObjectProperty',G).";
//		else getGraphDataObjectProperty = "rdf(HumanPerception, 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://knowrob.org/kb/knowrob.owl#VisualHumanPerception','"+filepath+"'),(rdf(HumanPerception,_,_,'"+filepath+"');rdf(_,_,HumanPerception,'"+filepath+"')).";
//		q = new Query(getGraphDataObjectProperty);
//		
//		while (q.hasMoreSolutions()) {
//			Map<String, Term> s = q.nextSolution();
//			
//			System.out.println("s :"+s);
//
//			for (int l = 0; l < s.size(); l++) {
//				System.out.println("s.values :"+s.values());
//			}
//			count++;
//		}
//		System.out.println("getGraphDataObjectProperty:"+count);
//		
//		count=0;
//		
//		String getGraphDataDataProperty = null;
//		if(filepath.contentEquals("")) getGraphDataDataProperty = "rdf(_, P, _,perception), rdf(P, 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://knowrob.org/kb/knowrob.owl#DatatypeProperty',G).";
//		else getGraphDataDataProperty = "rdf(HumanPerception, 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://knowrob.org/kb/knowrob.owl#VisualHumanPerception','"+filepath+"'),(rdf(HumanPerception,_,_,'"+filepath+"');rdf(_,_,HumanPerception,'"+filepath+"')).";
//		q = new Query(getGraphDataDataProperty);
//		
//		while (q.hasMoreSolutions()) {
//			q.nextSolution();
//			count++;
//		}
//		System.out.println("getGraphDataDataProperty:"+count);
//		
//		count=0;
//		
//		
//	}
//	
//	
//	
//		
////		final long timeInterval = 15000;
////		Runnable runnable = new Runnable() {
////			public void run() {
////				while (true) {
////					
////					// ------- code for task to run
////					// ------- ends here
////					Object argument1 = null;
////					String tripleCount = (String) tripleCountAction.execute(argument1);
////					System.out.println("recent triple count :" + tripleCount);
////
////					WorkingMemory_MonitorsArgument argument2 = new WorkingMemory_MonitorsArgument(
////							String.valueOf(taskManagerSubsList.size()));
////					String monitorCount = (String) workingMemroy_MonitorsAction.execute(argument2);
////					System.out.println("recent monitor count :" + monitorCount);
////					
////					Object argument4 = null;
////					int availableBattery =  (int) batteryAction.execute(argument4);
////					System.out.println("recent available battery :" + availableBattery);
////					
////					Object argument5 = null;
////					int availableMemory =  (int) availableMemoryAction.execute(argument5);
////					System.out.println("recent available memory :" + availableMemory);
////
////					try {
////						Thread.sleep(timeInterval);
////					} catch (InterruptedException e) {
////						e.printStackTrace();
////					}
////				}
////				
////			}
////		};
////		Thread thread = new Thread(runnable);
//
//
//		
//		
////		rdf(ObjectPerception, rdf:type, 'http://knowrob.org/kb/knowrob.owl#VisualObjectPerception'),rdf(ObjectPerception,_,_,perception);rdf(_,_,ObjectPerception,perception).
////		(rdfs_individuals_of(RobotPerception, 'http://knowrob.org/kb/knowrob.owl#VisualRobotPerception'), rdfs_individuals_of(RobotPerception, 'http://knowrob.org/kb/knowrob.owl#Proprioception')),rdf(RobotPerception,_,_,perception);rdf(_,_,RobotPerception,perception).
////		rdf(HumanPerception, rdf:type, 'http://knowrob.org/kb/knowrob.owl#VisualHumanPerception'),rdf(HumanPerception,_,_,perception);rdf(_,_,HumanPerception,perception).
////		rdf_save_db(Filename,perception)
//	
//}