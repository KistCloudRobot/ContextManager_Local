package kgu.agent.demo.action;

import kgu.agent.demo.action.ContextOntologyMonitor;
import kgu.agent.demo.action.LowLevelContextMonitor;

public class SharedData{
	public ContextOntologyMonitor COMD = new ContextOntologyMonitor();
	public LowLevelContextMonitor LCMD = new LowLevelContextMonitor();
}