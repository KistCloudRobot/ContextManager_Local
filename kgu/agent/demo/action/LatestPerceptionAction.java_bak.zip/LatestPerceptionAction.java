package kgu.agent.demo.action;


import static kgu.agent.demo.Configuration.*;

import java.util.Map;

import jpl.Query;
import jpl.Term;
import kgu.agent.demo.actionArgument.GLArgument;
import kgu.agent.demo.agent.ContextManager;
import kr.ac.uos.ai.arbi.agent.logger.ActionBody;
import kr.ac.uos.ai.arbi.ltm.DataSource;
import kr.ac.uos.ai.arbi.model.Binding;
import kr.ac.uos.ai.arbi.model.GeneralizedList;
import kr.ac.uos.ai.arbi.model.parser.GLParser;

public class LatestPerceptionAction implements ActionBody {
	private DataSource ds;
	
	
	public LatestPerceptionAction(DataSource ds) {
		this.ds = ds;
	}


	
	@Override
	public Object execute(Object o) {
		
		//여기에 ds 인자를 받아서 넣으시면 됩니다. 꼭 여기가 아니어도 ds 받아올때 사용하신 객체를 받아서 이 ds에 넣으시면 되요.
		
		GLArgument Log = (GLArgument) o;
		String data = Log.getGL();
		String t  = "";
		String perceptionType ="";
		String contents="";



		GLParser parser = new GLParser();

		GeneralizedList gl = null; // 입력 값 GL
		try {

			gl = parser.parseGL(data); // GL

		} catch (Exception ex) {
			ex.getStackTrace();
			System.out.println("Request format error. GL Fomat wrong");
		}
	    
		/*
		ds.assertFact("(type \"rotMat3D_human01\" \"RotationMatrix3D\")");
		ds.assertFact("(hasRotationMatrixElement \"rotMat3D_human01\" 1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1)");
		sc.nextLine();
		ds.assertFact("(type \"visualHumanPerception1\" \"VisualHumanPerception\")");
		ds.assertFact("(startTime \"visualHumanPerception1\" \""+ System.currentTimeMillis()+"\")");
		ds.assertFact("(objectActedOn \"visualHumanPerception1\" \"human01\")");
		ds.assertFact("(eventOccursAt \"visualHumanPerception1\" \"rotMat3D_human01\")");
		sc.nextLine();
		ds.assertFact("(type \"fall01\" \"Fall\")");
		ds.assertFact("(startTime \"fall01\" \""+ System.currentTimeMillis()+"\")");
		ds.assertFact("(endTime \"fall01\" \""+ (System.currentTimeMillis() + 5)+"\")");
		ds.assertFact("(doneBy \"fall01\" \"Human01\")");
		 * 
		 */
		/*
		   NOTIFY_TYPE = GLFactory.newGLFromGLString("(Type (object $object) (type $type))");
			NOTIFY_HASROTATIONMATRIX = GLFactory.newGLFromGLString("(HasRotationMatrix (rotationmatrix $rotationmatrix) (m00 $m00) (m01 $m01) (m02 $m02) (m03 $m03) (m10 $m10) (m11 $m11) (m12 $m12) (m13 $m13) (m20 $m20) (m21 $m21) (m22 $m22) (m23 $m23) ($m30 $m30) ($m31 $m31) ($m32 $m32) ($m33 $m33))");
			NOTIFY_STARTTIME = GLFactory.newGLFromGLString("(StartTime (perception $perception) (time $time))");
			NOTIFY_ENDTIME = GLFactory.newGLFromGLString("(EndTime (perception $perception) (time $time))");
			NOTIFY_DONEBY = GLFactory.newGLFromGLString("(DoneBy (action $action) (human $human))");
			NOTIFY_OBJECTACTEDON = GLFactory.newGLFromGLString("(ObjectActedOn (perception $perception) (object $object))");
			NOTIFY_EVENTOCCURSAT = GLFactory.newGLFromGLString("(EventOccursAt (perception $perception) (rotationmatrix $rotationmatrix))");
		 */
		//여기다가 예문 쓸게요
		//int testVar = 1;
		//ds.assertFact("(testGLName \"test1\" (glNestedName \"testArg\" \"" + testVar + "\"))");
		//이런 식으로 쓰시면 됩니다.
		/*
		 * /*
		 * NOTIFY_ACTION_PERCEPTION = GLFactory.newGLFromGLString("(actionPerception (actionType $actionType) (startTime $startTime) (endTime $endTime) (doneBy $action $human))");
		 * NOTIFY_VISUAL_HUMAN_PERCEPTION = GLFactory.newGLFromGLString("(visualHumanPerception (perception $perception)
		 *  (startTime $startTime) (endTime $endTime) (objectActedOn $objectActedOn) 
		 *  (eventOccursAt $eventOccursAt)
		 *   (matrix $m00 $m01 $m02 $m03 $m10 $m11 $m12 $m13 $m20 $m21 $m22 $m23 $m30 $m31 $m32 $m33))");
		 */
		 
		if (gl.getName().equals("visualHumanPerception")) {

			Binding b = NOTIFY_VISUAL_HUMAN_PERCEPTION.unify(gl, null);
			String perception = b.retrieve("$perception").asValue().stringValue();
			String startTime = b.retrieve("$startTime").asValue().stringValue();
			String objectActedOn = b.retrieve("$objectActedOn").asValue().stringValue();
			String eventOccursAt = b.retrieve("$eventOccursAt").asValue().stringValue();
			String m00 = b.retrieve("$m00").asValue().stringValue();
			String m01 = b.retrieve("$m01").asValue().stringValue();
			String m02 = b.retrieve("$m02").asValue().stringValue();
			String m03 = b.retrieve("$m03").asValue().stringValue();
			
			String m10 = b.retrieve("$m10").asValue().stringValue();
			String m11 = b.retrieve("$m11").asValue().stringValue();
			String m12 = b.retrieve("$m12").asValue().stringValue();
			String m13 = b.retrieve("$m13").asValue().stringValue();

			String m20 = b.retrieve("$m20").asValue().stringValue();
			String m21 = b.retrieve("$m21").asValue().stringValue();
			String m22 = b.retrieve("$m22").asValue().stringValue();
			String m23 = b.retrieve("$m23").asValue().stringValue();
			
			String m30 = b.retrieve("$m30").asValue().stringValue();
			String m31 = b.retrieve("$m31").asValue().stringValue();
			String m32 = b.retrieve("$m32").asValue().stringValue();
			String m33 = b.retrieve("$m33").asValue().stringValue();

			//assert perception type
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ perception
					+ "', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://robot-arbi.kr/ontologies/complexService.owl#VisualHumanPerception')";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			//assert startTime 
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#" + perception
					+ "', 'http://knowrob.org/kb/knowrob.owl#startTime', 'http://robot-arbi.kr/ontologies/complexService.owl#timepoint_"
					+ startTime + "')";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			//assert objectActedOn 
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#" + perception
					+ "', 'http://knowrob.org/kb/knowrob.owl#objectActedOn', 'http://robot-arbi.kr/ontologies/complexService.owl#"+ objectActedOn +"')";
			System.out.println(t + " " + (Query.hasSolution(t) ?"succeeded" : "failed"));
			
			//assert Matrix Name (eventOccursAt)
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#" + perception
					+ "', 'http://knowrob.org/kb/knowrob.owl#eventOccursAt', 'http://robot-arbi.kr/ontologies/complexService.owl#"
					+ eventOccursAt + "')";
			//Matrix Type
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#" + eventOccursAt
					+ "', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://robot-arbi.kr/ontologies/complexService.owl#RotationMatrix3D')";
			System.out.println(t + " " + (Query.hasSolution(t) ?"succeeded" : "failed"));
			
			//assert Pose 
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m00', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m00 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m01', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m01 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m02', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m02 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m03', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m03 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			//
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m10', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m10 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m11', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m11 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m12', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m12 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m13', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m13 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m20', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m20 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m21', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m21 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m22', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m22 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m23', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m23 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m30', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m30 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m31', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m31 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m32', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m32 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m33', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m33 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			//ds.assertFact("(testGLName \"test1\" (glNestedName \"testArg\" \"" + testVar + "\"))");
			
			String glToAssert = "(context (currentHumanPose (human \""+ objectActedOn +"\") (pose \""+ eventOccursAt +"\")))";
			System.out.println(glToAssert);
			ds.assertFact(glToAssert);
		}
		else if (gl.getName().equals("visualObjectPerception")) {

			Binding b = NOTIFY_VISUAL_OBJECT_PERCEPTION.unify(gl, null);
			String perception = b.retrieve("$perception").asValue().stringValue();
			String startTime = b.retrieve("$startTime").asValue().stringValue();
			String objectActedOn = b.retrieve("$objectActedOn").asValue().stringValue();
			String eventOccursAt = b.retrieve("$eventOccursAt").asValue().stringValue();
			String m00 = b.retrieve("$m00").asValue().stringValue();
			String m01 = b.retrieve("$m01").asValue().stringValue();
			String m02 = b.retrieve("$m02").asValue().stringValue();
			String m03 = b.retrieve("$m03").asValue().stringValue();
			
			String m10 = b.retrieve("$m10").asValue().stringValue();
			String m11 = b.retrieve("$m11").asValue().stringValue();
			String m12 = b.retrieve("$m12").asValue().stringValue();
			String m13 = b.retrieve("$m13").asValue().stringValue();

			String m20 = b.retrieve("$m20").asValue().stringValue();
			String m21 = b.retrieve("$m21").asValue().stringValue();
			String m22 = b.retrieve("$m22").asValue().stringValue();
			String m23 = b.retrieve("$m23").asValue().stringValue();
			
			String m30 = b.retrieve("$m30").asValue().stringValue();
			String m31 = b.retrieve("$m31").asValue().stringValue();
			String m32 = b.retrieve("$m32").asValue().stringValue();
			String m33 = b.retrieve("$m33").asValue().stringValue();

			//assert perception type
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ perception
					+ "', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://robot-arbi.kr/ontologies/complexService.owl#VisualObjectPerception')";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			//assert startTime 
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#" + perception
					+ "', 'http://knowrob.org/kb/knowrob.owl#startTime', 'http://robot-arbi.kr/ontologies/complexService.owl#timepoint_"
					+ startTime + "')";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			
			//assert objectActedOn 
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#" + perception
					+ "', 'http://knowrob.org/kb/knowrob.owl#objectActedOn', 'http://robot-arbi.kr/ontologies/complexService.owl#"+ objectActedOn +"')";
			System.out.println(t + " " + (Query.hasSolution(t) ?"succeeded" : "failed"));
			
			//assert Matrix Name (eventOccursAt)
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#" + perception
					+ "', 'http://knowrob.org/kb/knowrob.owl#eventOccursAt', 'http://robot-arbi.kr/ontologies/complexService.owl#"
					+ eventOccursAt + "')";
			//Matrix Type
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#" + eventOccursAt
					+ "', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://robot-arbi.kr/ontologies/complexService.owl#RotationMatrix3D')";
			System.out.println(t + " " + (Query.hasSolution(t) ?"succeeded" : "failed"));
			
			//asswert Pose 
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m00', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m00 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m01', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m01 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m02', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m02 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m03', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m03 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			//
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m10', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m10 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m11', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m11 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m12', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m12 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m13', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m13 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m20', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m20 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m21', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m21 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m22', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m22 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m23', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m23 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m30', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m30 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m31', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m31 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m32', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m32 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ eventOccursAt
					+ "', 'http://knowrob.org/kb/knowrob.owl#m33', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m33 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			//ds.assertFact("(testGLName \"test1\" (glNestedName \"testArg\" \"" + testVar + "\"))");
			
			String glToAssert = "(context (currentObjectPose (object \""+ objectActedOn +"\") (pose \""+ eventOccursAt +"\")))";
			System.out.println(glToAssert);
			ds.assertFact(glToAssert);
		}
		/*
		 * NOTIFY_ACTION_PERCEPTION = GLFactory.newGLFromGLString("(actionPerception 
		 * (actionType $actionType) 
		 * (startTime $startTime)
		 *  (endTime $endTime) 
		 *  (doneBy $action $human))");
		 */
		/*
		else if (gl.getName().equals("actionPerception")) {
			Binding b = NOTIFY_ACTION_PERCEPTION.unify(gl, null);
			
			String actionType = b.retrieve("$actionType").asValue().stringValue();
			String startTime = b.retrieve("$startTime").asValue().stringValue();
			String endTime = b.retrieve("$endTime").asValue().stringValue();
			String doneBy = b.retrieve("$doneBy").asValue().stringValue();
			
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ perception
					+ "', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://robot-arbi.kr/ontologies/complexService.owl#VisualObjectPerception')";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
		}*/
		/*
		//#########################################
		if (gl.getName().equals("type")) {

			Binding b = NOTIFY_TYPE.unify(gl, null);
			String object = b.retrieve("$object").asValue().stringValue();
			String type = b.retrieve("$type").asValue().stringValue();

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ object
					+ "', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://robot-arbi.kr/ontologies/complexService.owl#"+ type +"')";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			//ds.assertFact("(type ())");
		}
		else if (gl.getName().equals("hasRotationMatrixElement")) {

			Binding b = NOTIFY_HASROTATIONMATRIX.unify(gl, null);
			String rotationmatrix = b.retrieve("$rotationmatrix").asValue().stringValue();
			String m00 = b.retrieve("$m00").asValue().stringValue();
			String m01 = b.retrieve("$m01").asValue().stringValue();
			String m02 = b.retrieve("$m02").asValue().stringValue();
			String m03 = b.retrieve("$m03").asValue().stringValue();
			
			String m10 = b.retrieve("$m10").asValue().stringValue();
			String m11 = b.retrieve("$m11").asValue().stringValue();
			String m12 = b.retrieve("$m12").asValue().stringValue();
			String m13 = b.retrieve("$m13").asValue().stringValue();

			String m20 = b.retrieve("$m20").asValue().stringValue();
			String m21 = b.retrieve("$m21").asValue().stringValue();
			String m22 = b.retrieve("$m22").asValue().stringValue();
			String m23 = b.retrieve("$m23").asValue().stringValue();
			
			String m30 = b.retrieve("$m30").asValue().stringValue();
			String m31 = b.retrieve("$m31").asValue().stringValue();
			String m32 = b.retrieve("$m32").asValue().stringValue();
			String m33 = b.retrieve("$m33").asValue().stringValue();

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ rotationmatrix
					+ "', 'http://knowrob.org/kb/knowrob.owl#m00', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m00 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ rotationmatrix
					+ "', 'http://knowrob.org/kb/knowrob.owl#m01', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m01 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ rotationmatrix
					+ "', 'http://knowrob.org/kb/knowrob.owl#m02', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m02 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ rotationmatrix
					+ "', 'http://knowrob.org/kb/knowrob.owl#m03', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m03 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			//
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ rotationmatrix
					+ "', 'http://knowrob.org/kb/knowrob.owl#m10', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m10 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ rotationmatrix
					+ "', 'http://knowrob.org/kb/knowrob.owl#m11', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m11 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ rotationmatrix
					+ "', 'http://knowrob.org/kb/knowrob.owl#m12', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m12 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ rotationmatrix
					+ "', 'http://knowrob.org/kb/knowrob.owl#m13', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m13 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			//
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ rotationmatrix
					+ "', 'http://knowrob.org/kb/knowrob.owl#m20', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m20 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ rotationmatrix
					+ "', 'http://knowrob.org/kb/knowrob.owl#m21', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m21 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ rotationmatrix
					+ "', 'http://knowrob.org/kb/knowrob.owl#m22', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m22 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ rotationmatrix
					+ "', 'http://knowrob.org/kb/knowrob.owl#m23', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m23 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			//
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ rotationmatrix
					+ "', 'http://knowrob.org/kb/knowrob.owl#m30', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m30 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ rotationmatrix
					+ "', 'http://knowrob.org/kb/knowrob.owl#m31', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m31 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ rotationmatrix
					+ "', 'http://knowrob.org/kb/knowrob.owl#m32', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m32 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#"+ rotationmatrix
					+ "', 'http://knowrob.org/kb/knowrob.owl#m33', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ m33 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			
			//perceptionType ="hasRotationMatrixElement";
			//contents="";
		}
		
		else if (gl.getName().equals("startTime")) {
            
			Binding b = NOTIFY_STARTTIME.unify(gl, null);
			String perception = b.retrieve("$perception").asValue().stringValue();
			String time = b.retrieve("$time").asValue().stringValue();

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#" + perception
					+ "', 'http://knowrob.org/kb/knowrob.owl#startTime', 'http://robot-arbi.kr/ontologies/complexService.owl#timepoint_"
					+ time + "')";
			System.out.println(t + " " + (Query.hasSolution(t) ?"succeeded" : "failed"));
		}
		else if (gl.getName().equals("endTime")) {
            
			Binding b = NOTIFY_ENDTIME.unify(gl, null);
			String perception = b.retrieve("$perception").asValue().stringValue();
			String time = b.retrieve("$time").asValue().stringValue();

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#" + perception
					+ "', 'http://knowrob.org/kb/knowrob.owl#endTime', 'http://robot-arbi.kr/ontologies/complexService.owl#timepoint_"
					+ time + "')";  
			System.out.println(t + " " + (Query.hasSolution(t) ?"succeeded" : "failed"));
		}
		/*
		 * NOTIFY_DONEBY = GLFactory.newGLFromGLString("(DoneBy (action $action) (human $human))");
			NOTIFY_OBJECTACTEDON = GLFactory.newGLFromGLString("(ObjectActedOn (perception $perception) (object $object))");
			NOTIFY_EVENTOCCURSAT = GLFactory.newGLFromGLString("(EventOccursAt (perception $perception) (rotationmatrix $rotationmatrix))");
		 */
		/*
		else if (gl.getName().equals("doneBy")) {
            
			Binding b = NOTIFY_DONEBY.unify(gl, null);
			String action = b.retrieve("$action").asValue().stringValue();
			String human = b.retrieve("$human").asValue().stringValue();

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#" + action
					+ "', 'http://knowrob.org/kb/knowrob.owl#doneBy', 'http://robot-arbi.kr/ontologies/complexService.owl#"
					+ human + "')";
			System.out.println(t + " " + (Query.hasSolution(t) ?"succeeded" : "failed"));
		}
		
		else if (gl.getName().equals("objectActedOn")) {
            
			Binding b = NOTIFY_OBJECTACTEDON.unify(gl, null);
			String perception = b.retrieve("$perception").asValue().stringValue();
			String object = b.retrieve("$object").asValue().stringValue();

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#" + perception
					+ "', 'http://knowrob.org/kb/knowrob.owl#objectActedOn', 'http://robot-arbi.kr/ontologies/complexService.owl#"+ object +"')";
			System.out.println(t + " " + (Query.hasSolution(t) ?"succeeded" : "failed"));
		}
		
		else if (gl.getName().equals("eventOccursAt")) {
			Binding b = NOTIFY_EVENTOCCURSAT.unify(gl, null);
			String perception = b.retrieve("$perception").asValue().stringValue();
			String rotationmatrix = b.retrieve("$rotationmatrix").asValue().stringValue();

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#" + perception
					+ "', 'http://knowrob.org/kb/knowrob.owl#eventOccursAt', 'http://robot-arbi.kr/ontologies/complexService.owl#"
					+ rotationmatrix + "')";
			System.out.println(t + " " + (Query.hasSolution(t) ?"succeeded" : "failed"));
		}
		*/
		/*
		if (gl.getName().equals("Robot_position")) {

			Binding b = NOTIFY_ROBOT_POSITION.unify(gl, null);
			String time = b.retrieve("$time").asValue().stringValue();
			String pos1 = b.retrieve("$pos1").asValue().stringValue();
			String pos2 = b.retrieve("$pos2").asValue().stringValue();
			String angle = b.retrieve("$angle").asValue().stringValue();

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#rotationMatrix3DRobot" + (ContextManager.count)
					+ "', 'http://knowrob.org/kb/knowrob.owl#m03', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ pos1 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			// Query.hasSolution(t);
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#rotationMatrix3DRobot" + (ContextManager.count)
					+ "', 'http://knowrob.org/kb/knowrob.owl#m13', literal(type('http://www.w3.org/2001/XMLSchema#double', '"
					+ pos2 + "')))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			// Query.hasSolution(t);
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#rotationMatrix3DRobot" + (ContextManager.count)
					+ "', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://knowrob.org/kb/knowrob.owl#RotationMatrix3D')";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#locationPerception" + (ContextManager.count)
					+ "', 'http://knowrob.org/kb/knowrob.owl#startTime', 'http://robot-arbi.kr/ontologies/complexService.owl#timepoint_"
					+ (ContextManager.count) + "')";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#locationPerception" + (ContextManager.count)
					+ "', 'http://knowrob.org/kb/knowrob.owl#eventOccursAt', 'http://robot-arbi.kr/ontologies/complexService.owl#rotationMatrix3DRobot"
					+ (ContextManager.count) + "')";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#locationPerception" + (ContextManager.count)
					+ "', 'http://knowrob.org/kb/knowrob.owl#eventHasValue', literal(type('http://www.w3.org/2001/XMLSchema#double',  '"
					+ angle + "')))";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#locationPerception" + (ContextManager.count)
					+ "', 'http://knowrob.org/kb/knowrob.owl#objectActedOn', 'http://robot-arbi.kr/ontologies/complexService.owl#turtlebot01')";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#locationPerception" + (ContextManager.count++)
					+ "', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://robot-arbi.kr/ontologies/complexService.owl#LocationPerception')";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);
			
			/////// LatestRobotLocation
			
			t = "comp_locatedInRoom('http://robot-arbi.kr/ontologies/complexService.owl#turtlebot01', Room)";

			System.out.println("------------------" + t + "---------------------");
			Query q = new Query(t);
			String location = "";
			while (q.hasMoreSolutions()) {
				Map<String, Term> s3 = q.nextSolution();
				location = s3.get("Room").toString();

				System.out.println(s3.toString());
			}
			
			perceptionType ="LatestRobotLocation";
			contents=location;

	
			
			///////
		} else if (gl.getName().equals("Robot_battery")) {

			Binding b = NOTIFY_ROBOT_BATTERY.unify(gl, null);
			String time = b.retrieve("$time").asValue().stringValue();
			String gauge = b.retrieve("$gauge").asValue().stringValue();

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#batteryPerception" + (ContextManager.batteryCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#eventHasValue', literal(type('http://www.w3.org/2001/XMLSchema#double','"
					+ gauge + "')))";
			// + "', 'http://knowrob.org/kb/knowrob.owl#eventHasValue',
			// literal(type('http://www.w3.org/2001/XMLSchema#double','20')))";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#batteryPerception" + (ContextManager.batteryCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#startTime', 'http://robot-arbi.kr/ontologies/complexService.owl#timepoint_"
					+ (ContextManager.batteryCount) + "')";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#batteryPerception" + (ContextManager.batteryCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#objectActedOn', 'http://robot-arbi.kr/ontologies/complexService.owl#turtlebot01')";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#batteryPerception" + (ContextManager.batteryCount++)
					+ "', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://robot-arbi.kr/ontologies/complexService.owl#BatteryPerception')";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);

		} else if (gl.getName().equals("Robot_wheeldrop")) {

			Binding b = NOTIFY_ROBOT_WHEELDROP.unify(gl, null);
			String time = b.retrieve("$time").asValue().stringValue();
			String state = b.retrieve("$state").asValue().stringValue();

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#wheeldropPerception" + (ContextManager.wheeldropCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#eventHasValue', literal(type('http://www.w3.org/2001/XMLSchema#double',"
					+ state + ")))";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#wheeldropPerception" + (ContextManager.wheeldropCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#startTime', 'http://robot-arbi.kr/ontologies/complexService.owl#timepoint_"
					+ (ContextManager.wheeldropCount) + "')";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#wheeldropPerception" + (ContextManager.wheeldropCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#objectActedOn', 'http://robot-arbi.kr/ontologies/complexService.owl#turtlebot01')";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#wheeldropPerception" + (ContextManager.wheeldropCount++)
					+ "', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://robot-arbi.kr/ontologies/complexService.owl#WheeldropPerception')";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);

		}
	
		else if (gl.getName().equals("Robot_cliff")) {
			//(context (visualHumanPerception (test \"test) (test2 \"test)))
			Binding b = NOTIFY_ROBOT_CLIFF.unify(gl, null);
			String time = b.retrieve("$time").asValue().stringValue();
			String state = b.retrieve("$state").asValue().stringValue();

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#cliffPerception" + (ContextManager.cliffCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#eventHasValue', literal(type('http://www.w3.org/2001/XMLSchema#double',"
					+ state + ")))";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#cliffPerception" + (ContextManager.cliffCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#startTime', 'http://robot-arbi.kr/ontologies/complexService.owl#timepoint_"
					+ (ContextManager.cliffCount) + "')";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#cliffPerception" + (ContextManager.cliffCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#objectActedOn', 'http://robot-arbi.kr/ontologies/complexService.owl#turtlebot01')";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#cliffPerception" + (ContextManager.cliffCount++)
					+ "', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://robot-arbi.kr/ontologies/complexService.owl#CliffPerception')";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);

		}

		else if (gl.getName().equals("Robot_bumper")) {

			Binding b = NOTIFY_ROBOT_BUMPER.unify(gl, null);
			String time = b.retrieve("$time").asValue().stringValue();
			String state = b.retrieve("$state").asValue().stringValue();

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#bumperPerception" + (ContextManager.bumperCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#eventHasValue', literal(type('http://www.w3.org/2001/XMLSchema#double',"
					+ state + ")))";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#bumperPerception" + (ContextManager.bumperCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#startTime', 'http://robot-arbi.kr/ontologies/complexService.owl#timepoint_"
					+ (ContextManager.bumperCount) + "')";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);
			;

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#bumperPerception" + (ContextManager.bumperCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#objectActedOn', 'http://robot-arbi.kr/ontologies/complexService.owl#turtlebot01')";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#bumperPerception" + (ContextManager.bumperCount++)
					+ "', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://robot-arbi.kr/ontologies/complexService.owl#BumperPerception')";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);

		}

		else if (gl.getName().equals("Speech")) {

			Binding b = NOTIFY_ROBOT_SPEECH.unify(gl, null);
			String UserID = b.retrieve("$userID").asValue().stringValue();
			String time = b.retrieve("$time").asValue().stringValue();
			String sentence = b.retrieve("$sentence").asValue().stringValue();

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#speechPerception" + (ContextManager.speechCount)
			// + "',
			// 'http://robot-arbi.kr/ontologies/complexService.owl#speechContents',
			// literal(type('http://www.w3.org/2001/XMLSchema#string',"
			// + sentence + ")))";
					+ "', 'http://robot-arbi.kr/ontologies/complexService.owl#speechContents', '" + sentence + "')";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#speechPerception" + (ContextManager.speechCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#startTime', 'http://robot-arbi.kr/ontologies/complexService.owl#timepoint_"
					+ (ContextManager.speechCount) + "')";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#speechPerception" + (ContextManager.speechCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#objectActedOn', 'http://robot-arbi.kr/ontologies/complexService.owl#"
					+ UserID + "')";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#speechPerception" + (ContextManager.speechCount++)
					+ "', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://robot-arbi.kr/ontologies/complexService.owl#SpeechPerception')";
			// System.out.println(t + " " + (Query.hasSolution(t) ?
			// "succeeded" : "failed"));
			Query.hasSolution(t);
			perceptionType ="Voice";
			contents= sentence;

		}

		else if (gl.getName().equals("Human_tracking")) {

			Binding b = NOTIFY_ROBOT_HUMAN_TRACKING.unify(gl, null);
			String time = b.retrieve("$time").asValue().stringValue();
			String ID = b.retrieve("$userID").asValue().stringValue();
			String x = b.retrieve("$x").asValue().stringValue();
			String y = b.retrieve("$y").asValue().stringValue();
			String z = b.retrieve("$z").asValue().stringValue();

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#rotationMatrix3DHuman" + (ContextManager.HumanCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#m03', literal(type('http://www.w3.org/2001/XMLSchema#double', "
					+ x + ")))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			// Query.hasSolution(t);
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#rotationMatrix3DHuman" + (ContextManager.HumanCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#m13', literal(type('http://www.w3.org/2001/XMLSchema#double', "
					+ y + ")))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			// Query.hasSolution(t);
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#rotationMatrix3DHuman" + (ContextManager.HumanCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#m23', literal(type('http://www.w3.org/2001/XMLSchema#double',"
					+ z + ")))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			// Query.hasSolution(t);
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#rotationMatrix3DHuman" + (ContextManager.HumanCount)
					+ "', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://knowrob.org/kb/knowrob.owl#RotationMatrix3D')";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			// Query.hasSolution(t);
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#visualPerception" + (ContextManager.HumanCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#startTime', 'http://robot-arbi.kr/ontologies/complexService.owl#timepoint_"
					+ (ContextManager.HumanCount) + "')";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			// Query.hasSolution(t);
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#visualPerception" + (ContextManager.HumanCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#eventOccursAt', 'http://robot-arbi.kr/ontologies/complexService.owl#rotationMatrix3DHuman"
					+ (ContextManager.HumanCount) + "')";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			// Query.hasSolution(t);

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#visualPerception" + (ContextManager.HumanCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#objectActedOn','http://robot-arbi.kr/ontologies/complexService.owl#"
					+ ID + "')";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			// Query.hasSolution(t);

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#visualPerception" + (ContextManager.HumanCount++)
					+ "', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://knowrob.org/kb/knowrob.owl#VisualPerception')";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			// Query.hasSolution(t);
			
			perceptionType ="User";
			contents= ID;
		}
		else if (gl.getName().equals("HumanPerception")) {

			Binding b = NOTIFY_ROBOT_HUMAN_TRACKING.unify(gl, null);
			String time = b.retrieve("$time").asValue().stringValue();
			String ID = b.retrieve("$userID").asValue().stringValue();
			String x = b.retrieve("$x").asValue().stringValue();
			String y = b.retrieve("$y").asValue().stringValue();
			String z = b.retrieve("$z").asValue().stringValue();

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#rotationMatrix3DHuman" + (ContextManager.HumanCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#m03', literal(type('http://www.w3.org/2001/XMLSchema#double', "
					+ x + ")))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			// Query.hasSolution(t);
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#rotationMatrix3DHuman" + (ContextManager.HumanCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#m13', literal(type('http://www.w3.org/2001/XMLSchema#double', "
					+ y + ")))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			// Query.hasSolution(t);
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#rotationMatrix3DHuman" + (ContextManager.HumanCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#m23', literal(type('http://www.w3.org/2001/XMLSchema#double',"
					+ z + ")))";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			// Query.hasSolution(t);
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#rotationMatrix3DHuman" + (ContextManager.HumanCount)
					+ "', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://knowrob.org/kb/knowrob.owl#RotationMatrix3D')";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			// Query.hasSolution(t);
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#visualPerception" + (ContextManager.HumanCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#startTime', 'http://robot-arbi.kr/ontologies/complexService.owl#timepoint_"
					+ (ContextManager.HumanCount) + "')";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			// Query.hasSolution(t);
			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#visualPerception" + (ContextManager.HumanCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#eventOccursAt', 'http://robot-arbi.kr/ontologies/complexService.owl#rotationMatrix3DHuman"
					+ (ContextManager.HumanCount) + "')";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			// Query.hasSolution(t);

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#visualPerception" + (ContextManager.HumanCount)
					+ "', 'http://knowrob.org/kb/knowrob.owl#objectActedOn','http://robot-arbi.kr/ontologies/complexService.owl#"
					+ ID + "')";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			// Query.hasSolution(t);

			t = "rdf_assert('http://robot-arbi.kr/ontologies/complexService.owl#visualPerception" + (ContextManager.HumanCount++)
					+ "', 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://knowrob.org/kb/knowrob.owl#VisualPerception')";
			System.out.println(t + " " + (Query.hasSolution(t) ? "succeeded" : "failed"));
			// Query.hasSolution(t);
			
			perceptionType ="User";
			contents= ID;
		}
		*/

		return "Contents :"+ contents +" PerceptionType :"+perceptionType;
	}

}
