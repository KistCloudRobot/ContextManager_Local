:- module(arbi_convenient_service_globalVariable,
    []).


:- nb_setval(arbi_convenient_service_on_Physical_halfedge, 0.5).			%on_Physical
:- nb_setval(arbi_convenient_service_on_Physical_threshold, 0.05).			%on_Physical

:- nb_setval(arbi_convenient_service_in_Physical_intersectPer_threshold, 0.51).			%in_Physical

:- nb_setval(arbi_convenient_service_on_location_threshold, 0.74).			%on_location
