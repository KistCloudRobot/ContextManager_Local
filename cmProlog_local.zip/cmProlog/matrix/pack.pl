name(matrix).
title('Operations with matrices').
version('1.0').
author('Fabrizio Riguzzi', 'fabrizio.riguzzi@unife.it').
